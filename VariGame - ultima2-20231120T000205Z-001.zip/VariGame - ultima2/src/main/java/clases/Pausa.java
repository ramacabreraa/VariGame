package clases;

import javax.swing.JFrame;
import javax.swing.Timer;

public class Pausa extends JFrame {

    private final int ancho = 445, alto = 629;
    private Pausa2 pausa;
    private Timer looper;

    public Pausa(Timer looper) {
        this.looper = looper;

        setTitle("VariGame Blocks");
        setSize(ancho, alto);
        setLocationRelativeTo(null);
        setResizable(false);

        pausa = new Pausa2(looper);
        add(pausa);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
