package clases;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Info2 extends JPanel {

    // fondo
    private Image fondoimagen;

    public Info2() {

        setLayout(null);

        JButton volverButton = new JButton("Volver");
        volverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Menu menu = new Menu();
                menu.setVisible(true);
                menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                SwingUtilities.getWindowAncestor(Info2.this).dispose();
            }
        });

        volverButton.setBounds(75, 500, 280, 65);
        volverButton.setFocusPainted(false);
        volverButton.setBackground(new Color(255, 223, 43));
        volverButton.setForeground(new Color(69, 17, 173));
        volverButton.setFont(new Font("Segoe UI", Font.BOLD, 21));
        add(volverButton);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Fondo
        Dimension tamanio = getSize();
        fondoimagen = null;
        ImageIcon fondo = new ImageIcon(getClass().getResource("/imagenes/vari-info.png"));
        g.drawImage(fondo.getImage(), 0, 0, tamanio.width, tamanio.height, null);
        setOpaque(false);
    }
}
