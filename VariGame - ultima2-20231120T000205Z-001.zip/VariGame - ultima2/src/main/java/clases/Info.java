package clases;

import javax.swing.JFrame;

public class Info extends JFrame {

    private final int ancho = 445, alto = 629;
    private Info2 info;

    public Info() {

        setTitle("VariGame Blocks");
        setSize(ancho, alto);
        setLocationRelativeTo(null);
        setResizable(false);

        info = new Info2();
        add(info);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    

}
