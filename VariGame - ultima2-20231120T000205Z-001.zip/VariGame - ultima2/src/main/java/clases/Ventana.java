package clases;

import javax.swing.JFrame;

public class Ventana extends JFrame {

    private final int ancho = 445, alto = 629;
    private Juego tablero;

    public Ventana() {

        setTitle("VariGame Blocks");
        setSize(ancho, alto);
        setLocationRelativeTo(null);
        setResizable(false);

        tablero = new Juego();
        add(tablero);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        addKeyListener(tablero);
        
    }

}
