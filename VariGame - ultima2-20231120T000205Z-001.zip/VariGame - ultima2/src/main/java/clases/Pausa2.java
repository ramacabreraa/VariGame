package clases;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class Pausa2 extends JPanel {

    private Timer looper;
    // fondo
    private Image fondoimagen;

    public Pausa2(Timer looper) {
        this.looper = looper;
        setLayout(null);

        // Botones reinicio y salir
        JButton reiniciarButton = new JButton("Reanudar");
        reiniciarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Cerrar la ventana de pausa
                SwingUtilities.getWindowAncestor(Pausa2.this).dispose();

                // Reanudar el temporizador del juego
                looper.start();
            }
        });

        JButton salirButton = new JButton("Volver al menu principal");
        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        reiniciarButton.setBounds(75, 250, 280, 65);
        salirButton.setBounds(75, 370, 280, 65);

        reiniciarButton.setFocusPainted(false);
        salirButton.setFocusPainted(false);

        reiniciarButton.setBackground(new Color(255, 223, 43));
        reiniciarButton.setForeground(new Color(69, 17, 173));
        reiniciarButton.setFont(new Font("Segoe UI", Font.BOLD, 21));

        salirButton.setBackground(new Color(255, 223, 43));
        salirButton.setForeground(new Color(69, 17, 173));
        salirButton.setFont(new Font("Segoe UI", Font.BOLD, 21));

        // Agregar botones al panel
        add(reiniciarButton);
        add(salirButton);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Fondo
        Dimension tamanio = getSize();
        fondoimagen = null;
        ImageIcon fondo = new ImageIcon(getClass().getResource("/imagenes/pausita.png"));
        g.drawImage(fondo.getImage(), 0, 0, tamanio.width, tamanio.height, null);
        setOpaque(false);
    }
}
