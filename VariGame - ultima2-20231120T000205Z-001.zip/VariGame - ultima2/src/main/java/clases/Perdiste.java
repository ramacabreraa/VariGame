package clases;

import javax.swing.JFrame;

public class Perdiste extends JFrame {

    private final int ancho = 445, alto = 629;
    private Perdiste2 perdiste;

    public Perdiste() {

        setTitle("VariGame Blocks");
        setSize(ancho, alto);
        setLocationRelativeTo(null);
        setResizable(false);

        perdiste = new Perdiste2();
        add(perdiste);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }

}
