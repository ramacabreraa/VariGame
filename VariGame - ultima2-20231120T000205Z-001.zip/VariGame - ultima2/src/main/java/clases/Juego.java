package clases;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.sound.sampled.*;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Random;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class Juego extends JPanel implements KeyListener {

    // fondo
    private Image fondoimagen;

    private Pausa pausaVentana;
    //puntaje
    private int puntaje = -10;

    private long segundosRestantes;
    // Tamaño de la cuadrícula
    private final int boardHeight = 12;
    private final int boardWidth = 8;
    // Tamaño de un bloque en píxeles
    public static final int blockSize = 35;

    // Guarda el tiempo en que se inició la partida en milisegundos
    private long tiempoInicio;
    // Guarda el tiempo de la pieza actual
    private long tiempoInicioSegundoTemporizador = System.currentTimeMillis() + 10000;
    // movimiento
    private static int deltaX = 0;
    private static int deltaY = 0;
    // posición
    private int x = 3, y = 0;

    // colision
    public static boolean colision = false;

    private int[][] cords;

    private Color[][] shape = {
        {Color.RED, Color.RED, Color.RED},
        {null, Color.RED, null}
    };

    // piezas posibles
    //private Forma shapes = new Forma(shape1);
    // pieza actual
    private static Shape currentShape, nextShape;

    //timer
    private Timer looper;
    private int FPS = 60;
    private int delay = 90;

    // formas
    private int formaActualIndex;
    private int formaSiguienteIndex;

    //
    private Color[][] grid = new Color[boardHeight][boardWidth];

    // se puede pintar
    private boolean pintar = false;

    /*
    private Color[] colors = {Color.decode("#ed1c24"), Color.decode("#ff7f27"), Color.decode("#fff200"), 
        Color.decode("#22b14c"), Color.decode("#00a2e8"), Color.decode("#a349a4"), Color.decode("#3f48cc")};
    private Random random = new Random();
     */
    // board
    private Color[][][] formas = {
        // 1 Forma --
        {
            {Color.CYAN.darker(), Color.CYAN.darker(), Color.CYAN.darker(), Color.CYAN.darker()}
        },
        // 2 Forma I
        {
            {Color.ORANGE}, {Color.ORANGE}, {Color.ORANGE}
        },
        // 3 Forma I
        {
            {Color.CYAN}, {Color.CYAN}
        },
        // 4 Forma punto
        {
            {Color.BLUE.brighter()}
        },
        // 5 Forma T
        {
            {null, Color.RED, null},
            {Color.RED, Color.RED, Color.RED}
        },
        // 6 Forma L
        {
            {null, null, Color.ORANGE},
            {Color.ORANGE, Color.ORANGE, Color.ORANGE}
        },
        // 7 Forma O
        {
            {Color.YELLOW, Color.YELLOW},
            {Color.YELLOW, Color.YELLOW}
        },
        // 8 Forma L
        {
            {Color.MAGENTA, null, null},
            {Color.MAGENTA, Color.MAGENTA, Color.MAGENTA}
        },
        // 9 Forma [-]
        {
            {Color.RED, Color.RED, Color.RED},
            {Color.RED, Color.RED, Color.RED}
        }
    };

    public Juego() {

        // Genera un índice aleatorio para la forma actual
        Random random = new Random();
        formaActualIndex = random.nextInt(9);

        crearNuevaPieza();

        for (int i = 0; i < boardHeight; i++) {
            for (int j = 0; j < boardWidth; j++) {
                grid[i][j] = null;
            }
        }

        looper = new Timer(delay, new ActionListener() {
            int n = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                update();
                repaint();
            }
        });

        looper.start();
        tiempoInicio = System.currentTimeMillis(); // Inicializa el tiempo de inicio al crear el juego
        tiempoInicioSegundoTemporizador = System.currentTimeMillis();

    }

    private void update() {
        pintar = chequeopintar();

        if (colision && y >= 4 && pintar) {
            // Copia la forma actual en la matriz grid
            for (int i = 0; i < shape.length; i++) {
                for (int j = 0; j < shape[0].length; j++) {
                    if (shape[i][j] != null) {
                        grid[y + i][x + j] = shape[i][j];
                    }
                }
            }
            crearNuevaPieza();

            // Reiniciar el segundo temporizador
            tiempoInicioSegundoTemporizador = System.currentTimeMillis();

            //sumarPuntosGrillaDespintada();
            return;
        }

        eliminarFilasCompletas();
        eliminarColumnasCompletas();

        // Verifica si han pasado 5 segundos
        long tiempoTranscurridoSegundoTemporizador = System.currentTimeMillis() - tiempoInicioSegundoTemporizador;
        if (tiempoTranscurridoSegundoTemporizador >= 0 && puntaje >= 1000) {
            // Calcula el tiempo restante
            segundosRestantes = 5 - (tiempoTranscurridoSegundoTemporizador / 1000);
            if (segundosRestantes <= 0) {
                reiniciarJuego();  // Llama al método para reiniciar el juego
                return;
            }

        } else if (tiempoTranscurridoSegundoTemporizador >= 0 && puntaje >= 700) {
            // Calcula el tiempo restante
            segundosRestantes = 7 - (tiempoTranscurridoSegundoTemporizador / 1000);
            if (segundosRestantes <= 0) {
                reiniciarJuego();  // Llama al método para reiniciar el juego
                return;
            }

        } else if (tiempoTranscurridoSegundoTemporizador >= 0 && puntaje >= 350) {
            // Calcula el tiempo restante
            segundosRestantes = 10 - (tiempoTranscurridoSegundoTemporizador / 1000);
            if (segundosRestantes <= 0) {
                reiniciarJuego();  // Llama al método para reiniciar el juego
                return;
            }

        }
        
        else if (tiempoTranscurridoSegundoTemporizador >= 0 && puntaje >= 0) {
            // Calcula el tiempo restante
            segundosRestantes = 15 - (tiempoTranscurridoSegundoTemporizador / 1000);
            if (segundosRestantes <= 0) {
                reiniciarJuego();  // Llama al método para reiniciar el juego
                return;
            }

        }
        // Verifica si la forma está a menos de 4 filas del límite superior
        if (y < 4) {
            if (y + deltaY + shape.length <= 12 && y + deltaY >= 0) {
                y += deltaY;
            }
        } else {
            // Movimiento normal si la forma está por debajo de la fila 4
            if (y + deltaY + shape.length <= 12 && y + deltaY >= 4) {
                y += deltaY;
            }
        }

        // Movimiento lateral
        if (x + deltaX + shape[0].length <= 8 && x + deltaX >= 0) {
            x += deltaX;
        }

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Fondo
        Dimension tamanio = getSize();
        fondoimagen = null;
        ImageIcon fondo = new ImageIcon(getClass().getResource("/imagenes/vari-445-4.png"));
        g.drawImage(fondo.getImage(), 0, 0, tamanio.width, tamanio.height, null);
        setOpaque(false);

        //Graphics2D g2 = (Graphics2D) g;
        // Grid
        for (int i = 0; i < boardHeight; i++) {
            for (int j = 0; j < boardWidth; j++) {
                if (grid[i][j] != null) {
                    g.setColor(grid[i][j]);
                    g.fillRect(j * blockSize, i * blockSize, blockSize, blockSize);
                }
            }
        }

        // Dibuja formas
        for (int i = 0; i < formas[formaActualIndex].length; i++) {
            for (int j = 0; j < formas[formaActualIndex][0].length; j++) {
                if (formas[formaActualIndex][i][j] != null) {
                    g.setColor(formas[formaActualIndex][i][j]);
                    g.fillRect(j * blockSize + x * blockSize, i * blockSize + y * blockSize, blockSize, blockSize);

                    // Grosor del contorno
                    Graphics2D g2d = (Graphics2D) g;
                    g2d.setStroke(new BasicStroke(2));
                    g.setColor(Color.BLACK);
                    g.drawRect(j * blockSize + x * blockSize, i * blockSize + y * blockSize, blockSize, blockSize);
                }
            }
        }

        // Dibuja la siguiente forma
        for (int i = 0; i < formas[formaSiguienteIndex].length; i++) {
            for (int j = 0; j < formas[formaSiguienteIndex][0].length; j++) {
                if (formas[formaSiguienteIndex][i][j] != null) {
                    g.setColor(formas[formaSiguienteIndex][i][j]);
                    g.fillRect(boardWidth * 25 + 120 + j * 25, 50 + i * 25, 25, 25); // 25, menor al blockSize
                }
            }
        }

        // Dibuja la cuadrícula
        g.setColor(Color.WHITE);

        for (int i = 0; i <= boardHeight; i++) {
            g.drawLine(0, i * blockSize, boardWidth * blockSize, i * blockSize);
        }
        for (int j = 0; j <= boardWidth; j++) {
            g.drawLine(j * blockSize, 0, j * blockSize, boardHeight * blockSize);
        }

        // Dibuja el puntaje
        Color textColor = new Color(0xFF, 0xEA, 0x84);
        g.setColor(textColor);
        Font segoeUIFont = new Font("Segoe UI", Font.BOLD, 20);
        g.setFont(segoeUIFont);
        g.drawString(" " + puntaje, boardWidth * blockSize + 95, 183);

        // dibuja el tiempo restante
        g.setColor(Color.WHITE);
        g.setFont(segoeUIFont);
        g.drawString(" " + segundosRestantes, boardWidth * blockSize + 95, 247);

        // dibuja el tiempo de partida
        g.setColor(Color.WHITE);
        g.setFont(segoeUIFont);
        g.drawString(" " + getTiempoFormateado(), boardWidth * blockSize + 84, 325);

    }

    // mover fichas
    @Override
    public void keyPressed(KeyEvent e) {
        // movimiento y límites
        if (e.getKeyCode() == KeyEvent.VK_UP) {

            deltaY = -1;

        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {

            deltaX = 1;

        } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {

            deltaX = -1;

        } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {

            deltaY = 1;

        }

        if (e.getKeyCode() == KeyEvent.VK_P) {
            pausarJuego();
        }

        // enter
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {

            // Verifica si la pieza puede caer libremente
            int maxY = 0;
            for (int i = 0; i < shape.length; i++) {
                for (int j = 0; j < shape[0].length; j++) {
                    if (shape[i][j] != null) {
                        maxY = Math.max(maxY, i);
                    }
                }
            }

            // Calcula la posición vertical de la siguiente fila debajo de la pieza
            int nextY = y + maxY;

            // Verifica si la pieza puede caer en la siguiente fila
            boolean canFall = true;
            for (int i = 0; i < shape.length; i++) {
                for (int j = 0; j < shape[0].length; j++) {
                    if (shape[i][j] != null) {
                        if (nextY >= boardHeight || (nextY >= 0 && grid[nextY][x + j] != null)) {
                            canFall = false;
                            break;
                        }
                    }
                }
                if (!canFall) {
                    break;
                }
            }

            // Si la pieza puede caer, muévela hacia abajo
            if (canFall) {
                colision = true;
            }
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {

        if (e.getKeyCode() == KeyEvent.VK_UP) {

            deltaY = 0;

        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {

            deltaX = 0;

        } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {

            deltaX = 0;

        } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {

            deltaY = 0;
        }

        // enter
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            colision = false;
        }
    }

    private void crearNuevaPieza() {
        // Guarda la forma actual en grid
        for (int i = 0; i < formas[formaActualIndex].length; i++) {
            for (int j = 0; j < formas[formaActualIndex][0].length; j++) {
                if (formas[formaActualIndex][i][j] != null) {
                    grid[y + i][x + j] = formas[formaActualIndex][i][j];
                }
            }
        }

        formaActualIndex = formaSiguienteIndex;
        // Genera un índice aleatorio para la siguiente forma
        Random random = new Random();
        formaSiguienteIndex = random.nextInt(9); // número total de formas disponibles
        // Reinicia la posición de la forma actual
        x = 2;
        y = 0;

        // Incrementa el puntaje al colocar una pieza en la grilla
        puntaje += 10;

        // Reinicia la variable de colisión
        colision = false;

        // Inicializa la variable shape con la forma actual
        shape = formas[formaActualIndex];
    }

    private boolean chequeopintar() {
        for (int i = 0; i < shape.length; i++) {
            for (int j = 0; j < shape[0].length; j++) {
                if (shape[i][j] != null) {
                    int posY = y + i;
                    int posX = x + j;

                    if (grid[posY][posX] != null) {
                        return false; // No se puede pintar la pieza en esta posición
                    }
                }
            }
        }
        return true; // La pieza se puede pintar en la nueva posición
    }

    private void eliminarFilasCompletas() {
        for (int i = boardHeight - 1; i >= 0; i--) {

            boolean filaCompleta = true;

            for (int j = 0; j < boardWidth; j++) {
                if (grid[i][j] == null) {
                    filaCompleta = false;
                    break;
                }
            }

            if (filaCompleta) {
                puntaje += 50;
                // Si la fila está completa, se elimina
                for (int j = 0; j < boardWidth; j++) {
                    grid[i][j] = null;
                }
            }
        }
    }

    private void eliminarColumnasCompletas() {
        for (int i = boardWidth - 1; i >= 0; i--) {
            boolean columnaCompleta = true;

            for (int j = 4; j < boardHeight; j++) { // Empezamos desde la fila 4
                if (grid[j][i] == null) {
                    columnaCompleta = false;
                    break;
                }
            }

            if (columnaCompleta) {
                puntaje += 50;
                // Si la columna está completa, se elimina
                for (int j = 4; j < boardHeight; j++) { // Empezamos desde la fila 4
                    grid[j][i] = null;
                }
            }
        }
    }

    private String getTiempoFormateado() {
        long tiempoTranscurrido = System.currentTimeMillis() - tiempoInicio;
        long segundosTranscurridos = tiempoTranscurrido / 1000;
        long minutos = segundosTranscurridos / 60;
        long segundos = segundosTranscurridos % 60;
        return String.format("%02d:%02d", minutos, segundos);
    }

    private String getTiempoFormateadoSegundoTemporizador() {
        long tiempoTranscurrido = System.currentTimeMillis() - tiempoInicioSegundoTemporizador;
        long segundosTranscurridos = tiempoTranscurrido / 1000;
        long minutos = segundosTranscurridos / 60;
        long segundos = segundosTranscurridos % 60;
        return String.format("%02d:%02d", minutos, segundos);
    }

    public void reiniciarJuego() {
        // Detener el temporizador
        looper.stop();

        // Mostrar el frame "Perdiste"
        Perdiste perdiste = new Perdiste();
        perdiste.setVisible(true);
        perdiste.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Cerrar el frame actual
        SwingUtilities.getWindowAncestor(this).dispose();
        // Reiniciar el juego
        reiniciar();
    }

    private void reiniciar() {
        // Reiniciar variables y configuraciones del juego
        puntaje = -10;
        formaActualIndex = new Random().nextInt(9);
        crearNuevaPieza();

        for (int i = 0; i < boardHeight; i++) {
            for (int j = 0; j < boardWidth; j++) {
                grid[i][j] = null;
            }
        }

        // Reiniciar el temporizador
        looper.start();

        // Reiniciar el tiempo de inicio
        tiempoInicio = System.currentTimeMillis();
        tiempoInicioSegundoTemporizador = System.currentTimeMillis();
    }

    private void pausarJuego() {
        looper.stop();  // Detener el temporizador

        // Mostrar la ventana de pausa
        pausaVentana = new Pausa(looper);
        pausaVentana.setVisible(true);
        pausaVentana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    /*
    private void sumarPuntosGrillaDespintada() {
        if (esGrillaDespintada()) {
            puntaje += 200;
        }
    }

    private boolean esGrillaDespintada() {
        for (int i = 0; i < boardHeight; i++) {
            for (int j = 0; j < boardWidth; j++) {
                if (grid[i][j] != null) {
                    // Si encuentra al menos un bloque pintado, la grilla no está totalmente despintada
                    return false;
                }
            }
        }
        // Si no encuentra ningún bloque pintado, la grilla está totalmente despintada
        return true;
    }
     */
}
