package clases;

import javax.swing.JFrame;

public class Menu extends JFrame {

    private final int ancho = 445, alto = 629;
    private Menu2 menu;

    public Menu() {

        setTitle("VariGame Blocks");
        setSize(ancho, alto);
        setLocationRelativeTo(null);
        setResizable(false);

        menu = new Menu2();
        add(menu);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    

}
