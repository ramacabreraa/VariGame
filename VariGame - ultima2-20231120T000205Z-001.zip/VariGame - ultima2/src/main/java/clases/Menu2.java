package clases;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Menu2 extends JPanel {

    // fondo
    private Image fondoimagen;

    public Menu2() {

        setLayout(null);

        JButton jugarButton = new JButton("Jugar");
        jugarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear una nueva instancia de la Ventana
                Ventana ventana = new Ventana();
                ventana.setVisible(true);
                ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                // Cerrar el frame actual
                SwingUtilities.getWindowAncestor(Menu2.this).dispose();
            }
        });
        
        
        JButton infoButton = new JButton("Información");
        infoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Info info = new Info();
                info.setVisible(true);
                info.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                SwingUtilities.getWindowAncestor(Menu2.this).dispose();
            }
        });
        

        JButton salirButton = new JButton("Salir");
        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        jugarButton.setBounds(75, 300, 280, 65);
        infoButton.setBounds(75, 390, 280, 65);
        salirButton.setBounds(75, 480, 280, 65);

        jugarButton.setFocusPainted(false);
        infoButton.setFocusPainted(false);
        salirButton.setFocusPainted(false);

        jugarButton.setBackground(new Color(255, 223, 43));
        jugarButton.setForeground(new Color(69, 17, 173));
        jugarButton.setFont(new Font("Segoe UI", Font.BOLD, 21));
        
        infoButton.setBackground(new Color(255, 223, 43));
        infoButton.setForeground(new Color(69, 17, 173));
        infoButton.setFont(new Font("Segoe UI", Font.BOLD, 21));
        

        salirButton.setBackground(new Color(255, 223, 43));
        salirButton.setForeground(new Color(69, 17, 173));
        salirButton.setFont(new Font("Segoe UI", Font.BOLD, 21));

        // Agregar botones al panel
        add(jugarButton);
        add(infoButton);
        add(salirButton);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Fondo
        Dimension tamanio = getSize();
        fondoimagen = null;
        ImageIcon fondo = new ImageIcon(getClass().getResource("/imagenes/menu.png"));
        g.drawImage(fondo.getImage(), 0, 0, tamanio.width, tamanio.height, null);
        setOpaque(false);
    }
}
