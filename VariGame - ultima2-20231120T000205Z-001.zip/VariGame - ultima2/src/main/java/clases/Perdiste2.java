package clases;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Perdiste2 extends JPanel {

    // fondo
    private Image fondoimagen;

    public Perdiste2() {

        setLayout(null);

        // Botones reinicio y salir
        JButton reiniciarButton = new JButton("Reiniciar");
        reiniciarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear una nueva instancia de la Ventana
                Ventana ventana = new Ventana();
                ventana.setVisible(true);
                ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                // Cerrar el frame actual
                SwingUtilities.getWindowAncestor(Perdiste2.this).dispose();
            }
        });

        JButton salirButton = new JButton("Volver al menu principal");
        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear una nueva instancia del menu
                Menu menu = new Menu();
                menu.setVisible(true);
                menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                // Cerrar el frame actual
                SwingUtilities.getWindowAncestor(Perdiste2.this).dispose();
            }
        });

        reiniciarButton.setBounds(75, 300, 280, 65);
        salirButton.setBounds(75, 410, 280, 65);

        reiniciarButton.setFocusPainted(false);
        salirButton.setFocusPainted(false);

        reiniciarButton.setBackground(new Color(255, 223, 43));
        reiniciarButton.setForeground(new Color(69, 17, 173));
        reiniciarButton.setFont(new Font("Segoe UI", Font.BOLD, 21));

        salirButton.setBackground(new Color(255, 223, 43));
        salirButton.setForeground(new Color(69, 17, 173));
        salirButton.setFont(new Font("Segoe UI", Font.BOLD, 21));

        // Agregar botones al panel
        add(reiniciarButton);
        add(salirButton);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Fondo
        Dimension tamanio = getSize();
        fondoimagen = null;
        ImageIcon fondo = new ImageIcon(getClass().getResource("/imagenes/vari-perdiste.png"));
        g.drawImage(fondo.getImage(), 0, 0, tamanio.width, tamanio.height, null);
        setOpaque(false);
    }
}
