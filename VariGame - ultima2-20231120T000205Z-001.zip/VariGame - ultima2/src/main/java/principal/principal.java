package principal;

import clases.Menu;
import clases.Pausa;
import clases.Ventana;
import clases.Perdiste;
import javax.swing.JFrame;

public class principal {
    
    public static void main(String[] args){
        
        // Ventana juego
        /*Ventana ventana = new Ventana();
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);*/
        
        // Ventana perdiste
        /*Perdiste perdiste = new Perdiste();
        perdiste.setVisible(true);
        perdiste.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);*/
        
        // Ventana menu
        Menu menu = new Menu();
        menu.setVisible(true);
        menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
    }
           
}
